#!/bin/bash
set -e

# Put your custom bash command here
source /opt/ros/humble/setup.bash
source /home/ros/ros2_ws/install/setup.bash

# Execute the container's main command (passed via CMD)
exec "$@"
